package org.fundacionview.sgsst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sgsst79ApplicationTests {

	@Test
	void contextLoads() {
	}

}
