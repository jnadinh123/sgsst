package org.fundacionview.sgsst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sgsst79Application {

	public static void main(String[] args) {
		SpringApplication.run(Sgsst79Application.class, args);
	}

}
