package org.fundacionview.ejemplo1.modelos;

public interface ValidacionesLogin {

}
