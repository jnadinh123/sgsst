package org.fundacionview.ejemplo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
